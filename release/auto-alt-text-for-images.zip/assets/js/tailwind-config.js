tailwind.config = {
	theme: {
		extend: {
			colors: {
				'forvoyez-primary': '#4a90e2',
				'forvoyez-secondary': '#50e3c2',
			},
		},
	},
}
